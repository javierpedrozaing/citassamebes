<?php
namespace App\Exceptions;

class EmailAlreadyInSystemException extends \Exception
{

}