<?php
namespace App\Exceptions;

class ConnectionNotAcceptedException extends \Exception
{

}