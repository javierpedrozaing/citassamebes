<?php

namespace App\Exceptions;

class NoActiveAccountException extends \Exception
{

}