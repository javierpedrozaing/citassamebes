<?php
namespace App\Exceptions;

class TransactionFailedException extends \Exception
{

}
