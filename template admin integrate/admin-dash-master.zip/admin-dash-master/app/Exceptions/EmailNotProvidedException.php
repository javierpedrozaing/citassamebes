<?php

namespace App\Exceptions;


class EmailNotProvidedException extends \Exception
{



}