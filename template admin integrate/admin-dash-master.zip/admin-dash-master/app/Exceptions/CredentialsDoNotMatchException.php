<?php
namespace App\Exceptions;

class CredentialsDoNotMatchException extends \Exception
{

}