### Citefast

## Descripcion

Sistema de gestión de citas medicas e historia clínica.
El sistema permitirá configurar los datos básicos del centro de salud como también llevara la gestión del personal medico, mas los clientes del centro. A través del sistema se podrá agendar citas, atender cita y llevar una historia clínica (de acuerdo a como evolucione el sistema probablemente hasta en un futuro se le agregue un sistema de facturación).  El proyecto se dividira en dos partes Backend y Fronted, el backend estará construido en laravel con JWT, Entrust. El fronted sera puramente hecho en angular

## Canal Slack

[Slack: Link de invitacion](https://join.slack.com/t/citefast/shared_invite/enQtNDA5NDgzMDY2NDA1LTNjZGQ0ODQyNjViNjBkZGU4M2Y5M2RlYTU4NzI2MjhjZDA2YWZiNjRiNjA1OGZiYjRhOWQ4MzhhZDc2NjdmMjM)
